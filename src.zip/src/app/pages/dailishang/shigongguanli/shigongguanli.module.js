/**
 * @author a.demeshko
 * created on 1/12/16
 */
(function () {
  'use strict';

  angular.module('BlurAdmin.pages.dailishang.shigongguanli', [])
    .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider){
    // $stateProvider
    //   .state('ba.shigongguanli.shigongzhunbei', {
    //     url: '/shigongzhunbei',
    //     template: '<div></div>',
    //       title: '施工准备',
    //       sidebarMeta: {
    //         icon: 'ion-ios-pulse',
    //         order: 100,
    //       },
    //   })
    //   .state('ba.shigongguanli.shigongtu', {
    //     url: '/shigongtu',
    //     template: '<div></div>',
    //       title: '施工图管理',
    //       sidebarMeta: {
    //         icon: 'ion-ios-pulse',
    //         order: 100,
    //       },
    //   })
    //   .state('ba.shigongguanli.shigongjiedian', {
    //     url: '/shigongjiedian',
    //     template: '<div></div>',
    //       title: '施工节点管理',
    //       sidebarMeta: {
    //         icon: 'ion-ios-pulse',
    //         order: 100,
    //       },
    //   })
    //   .state('ba.shigongguanli.shigongjindu', {
    //     url: '/shigongjindu',
    //     template: '<div></div>',
    //       title: '施工进度管理',
    //       sidebarMeta: {
    //         icon: 'ion-ios-pulse',
    //         order: 100,
    //       },
    //   });
      
      


  }
})();