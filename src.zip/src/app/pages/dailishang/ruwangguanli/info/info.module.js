/**
 * @author a.demeshko
 * created on 1/12/16
 */
// (function () {
//   'use strict';

//   angular.module('BlurAdmin.pages.ruwangguanlia.info', [])
//     .config(routeConfig);

//   /** @ngInject */
//   function routeConfig($stateProvider){
//     $stateProvider
//       .state('ruwangguanlia.info', {
//         url: '/info',
//         controller: 'InfoCtrl',
//         templateUrl: 'app/pages/components/info/info.html',
//           title: '信息维护',
//           sidebarMeta: {
//             icon: 'ion-ios-pulse',
//             order: 100,
//           },
//       });
//   }
// })();
