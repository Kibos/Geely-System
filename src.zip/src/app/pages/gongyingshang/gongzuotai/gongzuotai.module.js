// /**
//  * @author a.demeshko
//  * created on 1/12/16
//  */
// (function () {
//   'use strict';

//   angular.module('BlurAdmin.pages.gongyingshang.gongzuotai', [])
//     .config(routeConfig);

//   /** @ngInject */
//   function routeConfig($stateProvider){
//     $stateProvider
//       .state('gongyingshang.gongzuotai', {
//         url: '/gongzuotai',
//         //controller: 'gongzuotaiCtrl',
//         template: '<div></div>',
//           title: '工作台',
//           sidebarMeta: {
//             icon: 'ion-ios-pulse',
//             order: 100,
//           },
//       })
//       .state('gongyingshang.jiandianguanli', {
//         url: '/jiandianguanli',
//         //controller: 'gongzuotaiCtrl',
//         templateUrl: '<div></div>',
//           title: '建店管理',
//           sidebarMeta: {
//             icon: 'ion-ios-pulse',
//             order: 100,
//           },
//       });
//   }
// })();
