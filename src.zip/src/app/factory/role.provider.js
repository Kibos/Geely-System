// angular.module('BlurAdmin')
// .provider('triMenu', menuProvider);

// function menuProvider() {

//   this.addMenu = addMenu;
//   function addMenu(item) {
//       console.log(item);
//   }


//   // Service
//   this.$get = function() {

//     return {
//         addMenu: addMenu
//     };

//   };

// }